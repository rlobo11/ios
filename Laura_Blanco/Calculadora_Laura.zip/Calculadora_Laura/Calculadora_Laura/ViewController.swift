//
//  ViewController.swift
//  Calculadora_Laura
//
//  Created by BCR on 17/4/18.
//  Copyright © 2018 JCMA. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var vOperacion1 : String = ""
    var vOperacion2 : String = ""
    var vNumero1 : Int = -1
    var vNumero2 : Int = -1
   
    var vAcumulado : Int = 0
    var vResultado : Int = 0
    var sNumero: String = ""
    var vIndicador: Int = 0
    var vContador: Int = 0
    
    
    @IBOutlet weak var lblOperacion: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btnNumeros(_ sender: UIButton) {
        
        lblOperacion.text! = lblOperacion.text! + String(sender.tag)
        
        if vIndicador == 0 {
            sNumero = String(sender.tag)
            vIndicador =  1
        }else{
            sNumero = sNumero + String(sender.tag)
            
        }
        
       if vOperacion1 != "" && vIndicador == 0 {
          Calculo(pTotal: false)
        }
        
    }
    
    @IBAction func btnOperacion(_ sender: UIButton) {
        if vOperacion1 == ""
        {
            vOperacion1 = sender.currentTitle!
        }else
        {
            vOperacion2 = sender.currentTitle!
        }
        Calculo(pTotal: false)
        vIndicador = 0
    }
    
    @IBAction func btnIgual(_ sender: UIButton) {
        Calculo(pTotal: true)
       
    }
    
    func Calculo(pTotal:Bool){
        
       switch vContador
       {
       case 0 :
            vNumero1 = Int(sNumero)!
            
            switch vOperacion1
            {
                case "+" :
                    vAcumulado = vAcumulado + vNumero1
                case "-":
                    vAcumulado = vAcumulado - vNumero1
                case "x":
                    if vAcumulado == 0 {
                        vAcumulado = vNumero1
                    }else{
                        vAcumulado = vAcumulado * vNumero1
                }
                
                case "÷":
                    if vAcumulado == 0 {
                        vAcumulado = vNumero1
                    }else{
                        vAcumulado = vAcumulado / vNumero1
                    }
                default: 0
            }
           
            vContador = vContador + 1
            if pTotal {
                lblOperacion.text! = lblOperacion.text!
            }else{
                lblOperacion.text! = lblOperacion.text! + vOperacion1
            }
            
            lblTotal.text! = String(vAcumulado)
        
       case 1 :
            vNumero2 = Int(sNumero)!
            switch vOperacion1
            {
                case "+" : vAcumulado = vAcumulado + vNumero2
                case "-": vAcumulado = vAcumulado - vNumero2
                case "x": vAcumulado = vAcumulado * vNumero2
                case "÷": vAcumulado = vAcumulado / vNumero2
                default: 0
            }
            vNumero1 = -1
            vOperacion1 = ""
            vContador = vContador + 1
            if pTotal {
                lblOperacion.text! = lblOperacion.text!
            }else{
                lblOperacion.text! = lblOperacion.text! + vOperacion2
            }
            
            
            lblTotal.text! = String(vAcumulado)
       case 2:
            vNumero2 = Int(sNumero)!
            switch vOperacion2
            {
                case "+" : vAcumulado = vAcumulado + vNumero2
                case "-": vAcumulado = vAcumulado - vNumero2
                case "x": vAcumulado = vAcumulado * vNumero2
                case "÷": vAcumulado = vAcumulado / vNumero2
                default: 0
            }
            vNumero1 = -1
            vNumero2 = -1
            vContador = 0
            if pTotal {
                lblOperacion.text! = lblOperacion.text!
            }else{
                lblOperacion.text! = lblOperacion.text! + vOperacion1
            }
            
            lblTotal.text! = String(vAcumulado)
         default: 0
        }
    }
   
    @IBAction func btnLimpiar(_ sender: UIButton) {
        lblTotal.text = ""
        lblOperacion.text = ""
        vOperacion1 = ""
        vNumero1 = -1
        vOperacion2 = ""
        vNumero2 = -1
        vAcumulado = 0
        vResultado = 0
        sNumero = ""
        vIndicador = 0
    }
 }

